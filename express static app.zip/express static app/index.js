var express=require('express')
const app=express()
const port=5000
const path=require('path')

const folderPath=path.join(__dirname + "/public")
app.use(express.static(folderPath))

app.get("/",(req,res)=>{
  res.sendFile(folderPath+  "/index.html")
})

app.get("/about",(req,res)=>{
  res.sendFile(folderPath + "/about.html")
})

app.get("/menu",(req,res)=>{
  res.sendFile(folderPath+  "/menu.html")
})

app.get("/reservation",(req,res)=>{
  res.sendFile(folderPath + "/reservation.html")
})

app.get("/service",(req,res)=>{
  res.sendFile(folderPath+  "/service.html")
})

app.get("/testimonial",(req,res)=>{
  res.sendFile(folderPath+  "/testimonial.html")
})

app.get("/contact",(req,res)=>{
  res.sendFile(folderPath+  "/contact.html")
})
app.get("*",(req,res)=>{
  res.sendFile(folderPath + "/404.html")
})

app.listen(port,()=>{
     console.log(`app running on port${port}`)
     console.log(`http://localhost:${port}`)
})