var http=require('http')
var fs=require('fs')
const port=5000
var path=require('path')
http.createServer((req,res)=>{
         var filePath= '.' + req.url
         if(filePath=='./'){
              filePath='./index.html'
         }
       var extname=path.extname(filePath)
       var contentType='text/html'
       switch(extname){
        case '.js' :
            contentType= 'text/javascript'
            break;
        case '.jpg' :
            contentType= 'image/jpg'
            break;
        case '.png' :
            contentType= 'image/png'
            break;
        case '.css' :
            contentType= 'text/css'
            break;
       }
       fs.readFile(filePath,(err,content)=>{
            if(err){
            if(err.code=="ENOENT"){
              fs.readFile('./404.html',(err,content)=>{
                     res.writeHead(200,{"Content-type":contentType})
                     res.end(content)
              })
             
            }
            else{
                res.writeHead(500)
                res.end("check error with this site!! Contact Admin" + err.code + '..\n')
                res.end()
            }
            }
            else{
                res.writeHead(200,{"Content-type":contentType})
                res.end(content)
            }
       })

})
.listen(port,()=>{
      console.log(`app running on ${port}`)
      console.log(`http://localhost:${port}`)
})