
////// this is connection file/////

var mongoose=require('mongoose')
mongoose.connect(mongoose.connect('mongodb://127.0.0.1:27017/batman'))
.then(()=>{
  console.log("successfully connected to mongodb")
})
.catch(()=>{
  console.log("connection error in mongodb")
})