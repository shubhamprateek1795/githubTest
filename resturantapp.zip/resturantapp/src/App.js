import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Nav from './components/Nav'
import About from './components/About'
import Contact from './components/Contact'
import Service from './components/Service'
import Menu from './components/Menu'
import Booking from './components/Booking'
import Team from './components/Team'
import Testimonial from './components/Testimonial'
import NotFound from './components/NotFound'
import Home from './components/Home'



function App() {
  return (
   <>
   <BrowserRouter>
   <Nav/>
   <Routes>
   <Route path='/' element={<Home/>}></Route>
   <Route path='/about' element={<About/>}></Route>
   <Route path='/service' element={<Service/>}></Route>
   <Route path='/menu' element={<Menu/>}></Route>
   <Route path='/booking' element={<Booking/>}></Route>
   <Route path='/team' element={<Team/>}></Route>
   <Route path='/testimonial' element={<Testimonial/>}></Route>
   <Route path='/contact' element={<Contact/>}></Route>
   <Route path='*' element={<NotFound/>}></Route>
 
   </Routes>
   </BrowserRouter>
   
   </>
  )
}

export default App
