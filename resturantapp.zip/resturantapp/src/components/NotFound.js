import React from 'react'
import { useNavigate } from 'react-router-dom'

function NotFound() {
    const redirect=useNavigate()
    const red=()=>{
        redirect("/")
    }
  return (
   <>
   <h1>Error 404 page not found</h1>
   <button onClick={red} >Go back to homepage</button>
   </>
  )
}

export default NotFound