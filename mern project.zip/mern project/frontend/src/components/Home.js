import React from 'react'

function Home() {
  return (
    <>
        <h1>homepage</h1>
        <p>this is paragraph</p>
    </>

  )
}

export default Home