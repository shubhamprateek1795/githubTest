var express=require('express')
var port=5000
const app=express()
const path=require('path')
const folderPath=path.join(__dirname)
const users=require("./data.json")
const fs=require('fs')
var session = require('express-session')

app.use(session({
    secret: 'express time',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
  }))



app.use(express.urlencoded({ extended: true }))

// parse application/json
app.use(express.json())


app.use(express.static(folderPath))
// app.use(express.json())
app.set('view engine','ejs')

app.get("/",(req,res)=>{
      res.render("index")
}) 

app.get("/about",(req,res)=>{
    res.render("about")
}) 
app.get("/contact",(req,res)=>{
    res.render("contact")
}) 
app.get("/register",(req,res)=>{
     res.render("register",{msg:""})
}) 


app.post("/register",(req,res)=>{
         let isValid=users.findIndex((u)=>{
               return u.email===req.body.email
         })
         if(isValid=== -1){
               let fileData=JSON.parse(fs.readFileSync("data.json"))
                fileData.push(req.body)
                fs.writeFileSync("data.json",JSON.stringify(fileData,null,4))
                res.render("register", {msg:"registered successfully"})
         } 
         else{
            res.render("register", {msg:"already registered with this mail id"})
         }
})
app.get("/dashboard",(req,res)=>{
    res.render("dashboard",{u:req.session.userData})
}) 

app.get("/login",(req,res)=>{
    res.render("login",{msg:""})
}) 



app.post("/login",(req,res)=>{
    let isValid=users.findIndex((u)=>{
    return (u.email===req.body.email && u.password===req.body.password)
    })
    if(isValid===-1){
        res.render("login",{msg:"login unsuccessful"}) 
    }
    else{
        req.session.userData=users[isValid]
        req.session.save()
        res.redirect("/dashboard")
    }
    
}) 


app.get("/logout",(req,res)=>{
    req.session.destroy((err)=> {
        res.redirect("login")
      })
  
}) 

app.get("*",(req,res)=>{
    res.render("404")
}) 
app.listen(port,()=>{
    console.log(`app running on ${port}`)
    console.log(`http://localhost:${port}`)
})