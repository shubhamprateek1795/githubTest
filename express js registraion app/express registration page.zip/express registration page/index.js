var express=require('express')
const app=express()
const users=require("./data.json")
const path=require('path')
const fs=require('fs')
var session=require('express-session')

app.use(session({
  secret: 'keyboard cat',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge:60000 }
}))

 
var folderPath=path.join(__dirname)
   
app.use(express.static(folderPath))
  
app.set("view engine", "ejs")
// parse application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: false }))

// parse application/json
app.use(express.json())




   app.get("/",(req,res)=>{
     res.render("index")
   })

   app.get("/about",(req,res)=>{
     res.render("about")
   })
   app.get("/contact",(req,res)=>{
      res.render("contact")
   })
   app.get("/dashboard",(req,res)=>{
    res.render("dashboard",{u:req.session.userData})
  })
   app.get("/register",(req,res)=>{
      res.render("register",{msg:""})
   })
   app.post("/register",(req,res)=>{
    let isValid=users.findIndex((u)=>{
       return u.email===req.body.email
    })
    if(isValid===-1){
      let FileName=JSON.parse(fs.readFileSync('data.json'))  
      FileName.push(req.body)
      fs.writeFileSync('data.json',JSON.stringify(FileName,null,1))
      res.render('register',{msg:'register successfully'})
    }
    else{
      res.render('register',{msg:'already registered with this mail id'})
    }
   })
   app.get("/login",(req,res)=>{
    res.render("login",{msg:""})
 })
   app.get("/logout",(req,res)=>{
    req.session.destroy(function(err) {
     res.redirect("login")
    })
  })
app.post("/login",(req,res)=>{
    let isValid=users.findIndex((u)=>{
      return u.email===req.body.email&& u.password=== req.body.password
    })
    if(isValid===-1){
      let FileName=JSON.parse(fs.readFileSync('data.json'))  
      FileName.push(req.body)
      res.render('login',{msg:'you are not registered with this email id'})
    }
    else{
      req.session.userData=users[isValid]
      req.session.save(function(err) {
       
      })
      res.redirect("/dashboard")
    }
})



   app.get("*",(req,res)=>{
     res.render("404")
   })
    app.listen(5000,()=>{
        console.log("app running on port 5000")
        console.log(`http://localhost:5000`)
    })